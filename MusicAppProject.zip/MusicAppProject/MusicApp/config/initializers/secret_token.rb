# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
MusicApp::Application.config.secret_key_base = '6c8e2c7692d65e817897e616e5e780c869e10fcdd0f8bbe9db397b26181a50a992a0ebb923f4345269c1629e95470f66511232c1e3d3bbbc9350f0dde608818c'
