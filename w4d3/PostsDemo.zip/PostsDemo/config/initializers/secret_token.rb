# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
PostsDemo::Application.config.secret_key_base = '70b43b8dc3d22437c89a5fbc9bb615cd006de78ee4990e4c8ff9ed24f5f4479e03875e4eab41128b4442e8f9da199c978a4c1828dd4d021b5e8faa0c3248baac'
