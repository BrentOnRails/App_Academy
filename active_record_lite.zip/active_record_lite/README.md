After the project, you can review the solution here:

* https://github.com/appacademy-solutions/active_record_lite/tree/solution
